@extends('admin.layouts.app')

@section('content')

                <!-- END BEGIN STYLE CUSTOMIZER -->

                <!-- BEGIN PAGE HEADER-->
                <div class="page-bar">
                    <ul class="page-breadcrumb">
                        <li>Dashboard</li>
                    </ul>
                </div>
                <!-- END PAGE HEADER-->
                <!-- BEGIN PAGE CONTENT-->
                <div class="row">
                    <div class="col-md-12">
                        <h3>Dashboard Content</h3>
                    </div>
                </div>
                <!-- END PAGE CONTENT-->


@endsection

@section('js')




    <script type="text/javascript">

        $(document).ready(function() {


        })

    </script>



@endsection